const mysql = require('mysql');


const conexion = mysql.createConnection ({
    host:'localhost',
    user:'root',
    password: '',
    database:'crud_node_js',
});

conexion.connect((error)=>{
    if(error){
        console.error('el error de la conexion es:'+error);
        return;
    }
    console.log('¡Conectado a la BD MYSQL!')
});

module.exports = conexion;